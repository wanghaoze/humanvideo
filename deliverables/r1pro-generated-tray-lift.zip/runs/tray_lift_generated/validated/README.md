# 双臂夹起托盘：程序生成的仿真轨迹

本轨迹是程序生成的 MuJoCo 仿真动作，不是人类 Quest 遥操示教，也未在真机执行。使用独立 scene_grip_solver.xml，未修改服务器正在使用的 scene_physics.xml。

验收：22 秒、20 Hz、440 帧；抬起后保持 8 秒，托盘最低碰撞表面离桌 12.84 cm，保持时垂直漂移 6.68 mm，最大倾斜 0.80 度。保持阶段双手接触持续存在，无桌面接触；全程未检测到机器人互碰。success 仅代表此空托盘抬起验收，不代表完整搬运/放置成功或真机可用。

## 文件
- replay.mp4：从记录的动作重新执行物理仿真得到的视频，不是直接设置托盘姿态的动画。
- trajectory.npz：动作、关节状态、完整 qpos/qvel、求解器 warm-start、托盘位置、时间和阶段。
- actions.csv：20 Hz 的 16 维关节位置/夹爪开度命令，列名给出关节顺序；不是末端位姿或力矩。
- report.json：验收、场景哈希、参数与版本。
- replay_validation.json：重新执行动作后的状态误差。
- contacts.json：每帧双手接触力、桌面接触和其他碰撞记录。

## 必须使用匹配场景

与原场景的唯一变化是 option.impratio 从默认 1 提高到 10，抑制 MuJoCo 软接触的数值缓慢滑移。托盘质量 1.2 kg、指尖滑动摩擦 1.2、夹爪 kp=2000 / kv=40、执行器驱动力上限 40 N 均未改。没有焊接、吸附或对托盘直接施加抬升力。

此前曾测试较高夹爪刚度，该测试版本未用于本交付。原场景下同一抓取策略会缓慢滑落，因此不能把本轨迹直接套用到未更新接触求解参数的服务并期待相同结果。

MuJoCo 官方说明：https://mujoco.readthedocs.io/en/latest/modeling.html#slow-slippage

## 在已有服务器项目中回放

将压缩包按相对路径解压到已安装好的 r1pro-tray-server 项目根目录；依赖该项目现有 outputs/r1pro_tray_scene/assets 目录。无需重新安装包，也不启动真实机器人接口。

```bash
MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=1 conda run -n r1pro-tray python scripts/replay_generated_tray_lift.py runs/tray_lift_generated/validated --scene outputs/r1pro_tray_scene/scene_grip_solver.xml
```

EGL_DEVICE_ID=1 对应此前已验证的服务器 GPU 0 渲染配置。回放结束生成 replay.mp4 和 replay_validation.json。该命令生成文件，不自动控制正在运行的 Quest 仿真服务。服务器数值一致性尚未测试。
