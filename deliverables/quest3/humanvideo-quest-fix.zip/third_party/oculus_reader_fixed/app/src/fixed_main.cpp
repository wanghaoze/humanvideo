// Humanvideo controller diagnostic client; uses Meta SampleXrFramework.
// Upstream SDK license and Oculus Reader license remain in their source trees.
#include "XrApp.h"
#include "Input/ControllerRenderer.h"
#include "Input/TinyUI.h"
#include "Render/SimpleBeamRenderer.h"
#include "Remotes.h"
#include <chrono>
#include <cstdio>

class HumanvideoReader : public OVRFW::XrApp {
    OVRFW::TinyUI ui;
    OVRFW::ControllerRenderer left, right;
    OVRFW::SimpleBeamRenderer beam;
    OVRFW::VRMenuObject* status = nullptr;
    bool exitRequested = false;
    std::chrono::steady_clock::time_point menuStart{};

    void Exit() {
        if (exitRequested) return;
        exitRequested = true;
        // Request normal Android activity teardown; the framework then receives
        // lifecycle events and tears down its OpenXR session.
        auto cls = Context.Env->GetObjectClass(Context.ActivityObject);
        auto method = Context.Env->GetMethodID(cls, "requestExit", "()V");
        if (method) Context.Env->CallVoidMethod(Context.ActivityObject, method);
        Context.Env->DeleteLocalRef(cls);
    }

public:
    HumanvideoReader() { BackgroundColor = {0.08f, 0.16f, 0.23f, 1.0f}; }

    bool AppInit(const xrJava* context) override {
        if (!ui.Init(context, GetFileSys())) return false;
        ui.AddLabel("Humanvideo Quest Reader", {0, 0.35f, -1.5f}, {900, 90});
        status = ui.AddLabel("Waiting for controllers", {0, 0.12f, -1.5f}, {900, 80});
        ui.AddLabel("Input only - no robot video", {0, -0.08f, -1.5f}, {900, 70});
        ui.AddLabel("Hold LEFT menu 2 seconds to exit", {0, -0.25f, -1.5f}, {900, 70});
        ui.AddButton("EXIT", {0, -0.45f, -1.5f}, {300, 90}, [this]() { Exit(); });
        return true;
    }

    bool SessionInit() override {
        CurrentSpace = LocalSpace;
        if (!left.Init(true) || !right.Init(false)) return false;
        beam.Init(GetFileSys(), nullptr, OVR::Vector4f(1.0f), 1.0f);
        return true;
    }

    void SessionEnd() override { left.Shutdown(); right.Shutdown(); beam.Shutdown(); }
    void AppShutdown(const xrJava* context) override { ui.Shutdown(); }

    void Update(const OVRFW::ovrApplFrameIn& in) override {
        ui.HitTestDevices().clear();
        if (in.LeftRemoteTracked) {
            left.Update(in.LeftRemotePose);
            ui.AddHitTestRay(in.LeftRemotePointPose, in.LeftRemoteIndexTrigger > 0.5f, 0);
        }
        if (in.RightRemoteTracked) {
            right.Update(in.RightRemotePose);
            ui.AddHitTestRay(in.RightRemotePointPose, in.RightRemoteIndexTrigger > 0.5f, 1);
        }
        char text[160];
        std::snprintf(text, sizeof(text), "Left: %s   Right: %s",
            in.LeftRemoteTracked ? "TRACKED" : "MISSING",
            in.RightRemoteTracked ? "TRACKED" : "MISSING");
        status->SetText(text);

        const auto now = std::chrono::steady_clock::now();
        const auto menu = GetActionStateBoolean(ButtonMenuAction);
        if (menu.isActive && menu.currentState) {
            if (menuStart == std::chrono::steady_clock::time_point{}) menuStart = now;
            if (now - menuStart >= std::chrono::seconds(2)) Exit();
        } else menuStart = {};

        RemoteState state{};
        const OVR::Matrix4f headInverse = OVR::Matrix4f(in.HeadPose).Inverted();
        if (in.LeftRemoteTracked)
            OVR::Matrix4f::Multiply(&state.LeftRemoteTransform, headInverse, OVR::Matrix4f(in.LeftRemotePose));
        if (in.RightRemoteTracked)
            OVR::Matrix4f::Multiply(&state.RightRemoteTransform, headInverse, OVR::Matrix4f(in.RightRemotePose));
        state.buttonA = GetActionStateBoolean(ButtonAAction).currentState;
        state.buttonB = GetActionStateBoolean(ButtonBAction).currentState;
        state.buttonX = GetActionStateBoolean(ButtonXAction).currentState;
        state.buttonY = GetActionStateBoolean(ButtonYAction).currentState;
        if (Focused && !exitRequested) {
            const auto wire = remotes_to_string(state, in);
            __android_log_print(ANDROID_LOG_INFO, "wE9ryARX", "%s", wire.c_str());
        }
        ui.Update(in);
        beam.Update(in, ui.HitTestDevices());
    }

    void Render(const OVRFW::ovrApplFrameIn& in, OVRFW::ovrRendererOutput& out) override {
        ui.Render(in, out);
        if (in.LeftRemoteTracked) left.Render(out.Surfaces);
        if (in.RightRemoteTracked) right.Render(out.Surfaces);
        beam.Render(in, out);
    }
};

ENTRY_POINT(HumanvideoReader)
