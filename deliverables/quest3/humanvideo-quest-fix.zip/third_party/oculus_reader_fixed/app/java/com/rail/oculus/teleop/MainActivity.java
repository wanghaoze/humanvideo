/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * Licensed under the Oculus SDK License Agreement (the "License");
 * you may not use the Oculus SDK except in compliance with the License,
 * which is provided at the time of installation or download, or which
 * otherwise accompanies this software in either electronic or hard copy form.
 *
 * You may obtain a copy of the License at
 * https://developer.oculus.com/licenses/oculussdk/
 *
 * Unless required by applicable law or agreed to in writing, the Oculus SDK
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.rail.oculus.teleop;

public class MainActivity extends android.app.NativeActivity {
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    @Override public void onCreate(android.os.Bundle state) {
        super.onCreate(state);
        // Optional bounded diagnostic run, independent of the native render loop.
        int seconds = getIntent().getIntExtra("diagnostic_timeout_seconds", 0);
        if (seconds > 0) handler.postDelayed(this::requestExit, Math.min(seconds, 120) * 1000L);
    }
    public void requestExit() { runOnUiThread(this::finishAndRemoveTask); }
    @Override public void onBackPressed() { requestExit(); }
    @Override public void onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
